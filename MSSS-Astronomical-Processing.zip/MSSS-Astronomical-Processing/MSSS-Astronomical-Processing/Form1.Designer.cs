﻿namespace MSSS_Astronomical_Processing
{
	partial class Form1
	{
		/// <summary>
		///  Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		///  Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		///  Required method for Designer support - do not modify
		///  the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
			toolStrip1 = new ToolStrip();
			toolStripLabel1 = new ToolStripLabel();
			toolStripSeparator1 = new ToolStripSeparator();
			toolStripDropDownButton1 = new ToolStripDropDownButton();
			languageToolStripMenuItem = new ToolStripMenuItem();
			englishUKToolStripMenuItem = new ToolStripMenuItem();
			frenchFrançaisToolStripMenuItem = new ToolStripMenuItem();
			germanDeutschToolStripMenuItem = new ToolStripMenuItem();
			appearanceToolStripMenuItem = new ToolStripMenuItem();
			darkModeToolStripMenuItem = new ToolStripMenuItem();
			lightModeToolStripMenuItem = new ToolStripMenuItem();
			customBackgroundToolStripMenuItem = new ToolStripMenuItem();
			fontSettingsToolStripMenuItem = new ToolStripMenuItem();
			statusStrip1 = new StatusStrip();
			toolStripStatusLabel1 = new ToolStripStatusLabel();
			toolStripStatusLabel2 = new ToolStripStatusLabel();
			flowLayoutPanel1 = new FlowLayoutPanel();
			groupBox1 = new GroupBox();
			listView1 = new ListView();
			label3 = new Label();
			button1 = new Button();
			textBox2 = new TextBox();
			label2 = new Label();
			textBox1 = new TextBox();
			label1 = new Label();
			groupBox2 = new GroupBox();
			listView2 = new ListView();
			label4 = new Label();
			button2 = new Button();
			textBox4 = new TextBox();
			label6 = new Label();
			groupBox3 = new GroupBox();
			listView3 = new ListView();
			label5 = new Label();
			button3 = new Button();
			textBox3 = new TextBox();
			label7 = new Label();
			groupBox4 = new GroupBox();
			listView4 = new ListView();
			label8 = new Label();
			button4 = new Button();
			textBox5 = new TextBox();
			label9 = new Label();
			toolStrip1.SuspendLayout();
			statusStrip1.SuspendLayout();
			flowLayoutPanel1.SuspendLayout();
			groupBox1.SuspendLayout();
			groupBox2.SuspendLayout();
			groupBox3.SuspendLayout();
			groupBox4.SuspendLayout();
			SuspendLayout();
			// 
			// toolStrip1
			// 
			resources.ApplyResources(toolStrip1, "toolStrip1");
			toolStrip1.ImageScalingSize = new Size(24, 24);
			toolStrip1.Items.AddRange(new ToolStripItem[] { toolStripLabel1, toolStripSeparator1, toolStripDropDownButton1 });
			toolStrip1.Name = "toolStrip1";
			// 
			// toolStripLabel1
			// 
			resources.ApplyResources(toolStripLabel1, "toolStripLabel1");
			toolStripLabel1.Name = "toolStripLabel1";
			// 
			// toolStripSeparator1
			// 
			resources.ApplyResources(toolStripSeparator1, "toolStripSeparator1");
			toolStripSeparator1.Name = "toolStripSeparator1";
			// 
			// toolStripDropDownButton1
			// 
			resources.ApplyResources(toolStripDropDownButton1, "toolStripDropDownButton1");
			toolStripDropDownButton1.DisplayStyle = ToolStripItemDisplayStyle.Text;
			toolStripDropDownButton1.DropDownItems.AddRange(new ToolStripItem[] { languageToolStripMenuItem, appearanceToolStripMenuItem });
			toolStripDropDownButton1.Name = "toolStripDropDownButton1";
			// 
			// languageToolStripMenuItem
			// 
			resources.ApplyResources(languageToolStripMenuItem, "languageToolStripMenuItem");
			languageToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { englishUKToolStripMenuItem, frenchFrançaisToolStripMenuItem, germanDeutschToolStripMenuItem });
			languageToolStripMenuItem.Name = "languageToolStripMenuItem";
			// 
			// englishUKToolStripMenuItem
			// 
			resources.ApplyResources(englishUKToolStripMenuItem, "englishUKToolStripMenuItem");
			englishUKToolStripMenuItem.Name = "englishUKToolStripMenuItem";
			// 
			// frenchFrançaisToolStripMenuItem
			// 
			resources.ApplyResources(frenchFrançaisToolStripMenuItem, "frenchFrançaisToolStripMenuItem");
			frenchFrançaisToolStripMenuItem.Name = "frenchFrançaisToolStripMenuItem";
			// 
			// germanDeutschToolStripMenuItem
			// 
			resources.ApplyResources(germanDeutschToolStripMenuItem, "germanDeutschToolStripMenuItem");
			germanDeutschToolStripMenuItem.Name = "germanDeutschToolStripMenuItem";
			// 
			// appearanceToolStripMenuItem
			// 
			resources.ApplyResources(appearanceToolStripMenuItem, "appearanceToolStripMenuItem");
			appearanceToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { lightModeToolStripMenuItem, darkModeToolStripMenuItem, customBackgroundToolStripMenuItem, fontSettingsToolStripMenuItem });
			appearanceToolStripMenuItem.Name = "appearanceToolStripMenuItem";
			// 
			// darkModeToolStripMenuItem
			// 
			resources.ApplyResources(darkModeToolStripMenuItem, "darkModeToolStripMenuItem");
			darkModeToolStripMenuItem.Name = "darkModeToolStripMenuItem";
			// 
			// lightModeToolStripMenuItem
			// 
			resources.ApplyResources(lightModeToolStripMenuItem, "lightModeToolStripMenuItem");
			lightModeToolStripMenuItem.Name = "lightModeToolStripMenuItem";
			// 
			// customBackgroundToolStripMenuItem
			// 
			resources.ApplyResources(customBackgroundToolStripMenuItem, "customBackgroundToolStripMenuItem");
			customBackgroundToolStripMenuItem.Name = "customBackgroundToolStripMenuItem";
			// 
			// fontSettingsToolStripMenuItem
			// 
			resources.ApplyResources(fontSettingsToolStripMenuItem, "fontSettingsToolStripMenuItem");
			fontSettingsToolStripMenuItem.Name = "fontSettingsToolStripMenuItem";
			// 
			// statusStrip1
			// 
			resources.ApplyResources(statusStrip1, "statusStrip1");
			statusStrip1.ImageScalingSize = new Size(24, 24);
			statusStrip1.Items.AddRange(new ToolStripItem[] { toolStripStatusLabel1, toolStripStatusLabel2 });
			statusStrip1.Name = "statusStrip1";
			// 
			// toolStripStatusLabel1
			// 
			resources.ApplyResources(toolStripStatusLabel1, "toolStripStatusLabel1");
			toolStripStatusLabel1.Name = "toolStripStatusLabel1";
			// 
			// toolStripStatusLabel2
			// 
			resources.ApplyResources(toolStripStatusLabel2, "toolStripStatusLabel2");
			toolStripStatusLabel2.Name = "toolStripStatusLabel2";
			// 
			// flowLayoutPanel1
			// 
			resources.ApplyResources(flowLayoutPanel1, "flowLayoutPanel1");
			flowLayoutPanel1.Controls.Add(groupBox1);
			flowLayoutPanel1.Controls.Add(groupBox2);
			flowLayoutPanel1.Controls.Add(groupBox3);
			flowLayoutPanel1.Controls.Add(groupBox4);
			flowLayoutPanel1.Name = "flowLayoutPanel1";
			// 
			// groupBox1
			// 
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.Controls.Add(listView1);
			groupBox1.Controls.Add(label3);
			groupBox1.Controls.Add(button1);
			groupBox1.Controls.Add(textBox2);
			groupBox1.Controls.Add(label2);
			groupBox1.Controls.Add(textBox1);
			groupBox1.Controls.Add(label1);
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			// 
			// listView1
			// 
			resources.ApplyResources(listView1, "listView1");
			listView1.Name = "listView1";
			listView1.UseCompatibleStateImageBehavior = false;
			// 
			// label3
			// 
			resources.ApplyResources(label3, "label3");
			label3.Name = "label3";
			// 
			// button1
			// 
			resources.ApplyResources(button1, "button1");
			button1.Name = "button1";
			button1.UseVisualStyleBackColor = true;
			// 
			// textBox2
			// 
			resources.ApplyResources(textBox2, "textBox2");
			textBox2.Name = "textBox2";
			// 
			// label2
			// 
			resources.ApplyResources(label2, "label2");
			label2.Name = "label2";
			// 
			// textBox1
			// 
			resources.ApplyResources(textBox1, "textBox1");
			textBox1.Name = "textBox1";
			// 
			// label1
			// 
			resources.ApplyResources(label1, "label1");
			label1.Name = "label1";
			// 
			// groupBox2
			// 
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.Controls.Add(listView2);
			groupBox2.Controls.Add(label4);
			groupBox2.Controls.Add(button2);
			groupBox2.Controls.Add(textBox4);
			groupBox2.Controls.Add(label6);
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			// 
			// listView2
			// 
			resources.ApplyResources(listView2, "listView2");
			listView2.Name = "listView2";
			listView2.UseCompatibleStateImageBehavior = false;
			// 
			// label4
			// 
			resources.ApplyResources(label4, "label4");
			label4.Name = "label4";
			// 
			// button2
			// 
			resources.ApplyResources(button2, "button2");
			button2.Name = "button2";
			button2.UseVisualStyleBackColor = true;
			// 
			// textBox4
			// 
			resources.ApplyResources(textBox4, "textBox4");
			textBox4.Name = "textBox4";
			// 
			// label6
			// 
			resources.ApplyResources(label6, "label6");
			label6.Name = "label6";
			// 
			// groupBox3
			// 
			resources.ApplyResources(groupBox3, "groupBox3");
			groupBox3.Controls.Add(listView3);
			groupBox3.Controls.Add(label5);
			groupBox3.Controls.Add(button3);
			groupBox3.Controls.Add(textBox3);
			groupBox3.Controls.Add(label7);
			groupBox3.Name = "groupBox3";
			groupBox3.TabStop = false;
			// 
			// listView3
			// 
			resources.ApplyResources(listView3, "listView3");
			listView3.Name = "listView3";
			listView3.UseCompatibleStateImageBehavior = false;
			// 
			// label5
			// 
			resources.ApplyResources(label5, "label5");
			label5.Name = "label5";
			// 
			// button3
			// 
			resources.ApplyResources(button3, "button3");
			button3.Name = "button3";
			button3.UseVisualStyleBackColor = true;
			// 
			// textBox3
			// 
			resources.ApplyResources(textBox3, "textBox3");
			textBox3.Name = "textBox3";
			// 
			// label7
			// 
			resources.ApplyResources(label7, "label7");
			label7.Name = "label7";
			// 
			// groupBox4
			// 
			resources.ApplyResources(groupBox4, "groupBox4");
			groupBox4.Controls.Add(listView4);
			groupBox4.Controls.Add(label8);
			groupBox4.Controls.Add(button4);
			groupBox4.Controls.Add(textBox5);
			groupBox4.Controls.Add(label9);
			groupBox4.Name = "groupBox4";
			groupBox4.TabStop = false;
			// 
			// listView4
			// 
			resources.ApplyResources(listView4, "listView4");
			listView4.Name = "listView4";
			listView4.UseCompatibleStateImageBehavior = false;
			// 
			// label8
			// 
			resources.ApplyResources(label8, "label8");
			label8.Name = "label8";
			// 
			// button4
			// 
			resources.ApplyResources(button4, "button4");
			button4.Name = "button4";
			button4.UseVisualStyleBackColor = true;
			// 
			// textBox5
			// 
			resources.ApplyResources(textBox5, "textBox5");
			textBox5.Name = "textBox5";
			// 
			// label9
			// 
			resources.ApplyResources(label9, "label9");
			label9.Name = "label9";
			// 
			// Form1
			// 
			resources.ApplyResources(this, "$this");
			AutoScaleMode = AutoScaleMode.Font;
			Controls.Add(flowLayoutPanel1);
			Controls.Add(statusStrip1);
			Controls.Add(toolStrip1);
			FormBorderStyle = FormBorderStyle.FixedSingle;
			MaximizeBox = false;
			Name = "Form1";
			toolStrip1.ResumeLayout(false);
			toolStrip1.PerformLayout();
			statusStrip1.ResumeLayout(false);
			statusStrip1.PerformLayout();
			flowLayoutPanel1.ResumeLayout(false);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			groupBox2.ResumeLayout(false);
			groupBox2.PerformLayout();
			groupBox3.ResumeLayout(false);
			groupBox3.PerformLayout();
			groupBox4.ResumeLayout(false);
			groupBox4.PerformLayout();
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private ToolStrip toolStrip1;
		private ToolStripLabel toolStripLabel1;
		private ToolStripSeparator toolStripSeparator1;
		private ToolStripDropDownButton toolStripDropDownButton1;
		private ToolStripMenuItem languageToolStripMenuItem;
		private ToolStripMenuItem englishUKToolStripMenuItem;
		private ToolStripMenuItem frenchFrançaisToolStripMenuItem;
		private ToolStripMenuItem appearanceToolStripMenuItem;
		private ToolStripMenuItem germanDeutschToolStripMenuItem;
		private ToolStripMenuItem darkModeToolStripMenuItem;
		private ToolStripMenuItem lightModeToolStripMenuItem;
		private ToolStripMenuItem customBackgroundToolStripMenuItem;
		private ToolStripMenuItem fontSettingsToolStripMenuItem;
		private StatusStrip statusStrip1;
		private ToolStripStatusLabel toolStripStatusLabel1;
		private ToolStripStatusLabel toolStripStatusLabel2;
		private FlowLayoutPanel flowLayoutPanel1;
		private GroupBox groupBox1;
		private Label label1;
		private TextBox textBox2;
		private Label label2;
		private TextBox textBox1;
		private Button button1;
		private ListView listView1;
		private Label label3;
		private GroupBox groupBox2;
		private ListView listView2;
		private Label label4;
		private Button button2;
		private TextBox textBox4;
		private Label label6;
		private GroupBox groupBox3;
		private ListView listView3;
		private Label label5;
		private Button button3;
		private TextBox textBox3;
		private Label label7;
		private GroupBox groupBox4;
		private ListView listView4;
		private Label label8;
		private Button button4;
		private TextBox textBox5;
		private Label label9;
	}
}
